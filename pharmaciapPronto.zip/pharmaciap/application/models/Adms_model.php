<?php

class Adms_model extends CI_Model{

    //pega tudo no métoo post e manda para tabela usuarios
        public function logarAdm($matricula_adm, $senha_adm){
            //depois de pegar ele no metedo post
            //chegar ele no banco de dados e trazer
            $this->db->where("matricula_adm", $matricula_adm);
            $this->db->where("senha_adm", $senha_adm);
            //montando adm
            // onde matricula for igual name e senha igual senha (row_array) = pegando somente uma linha
            $adm =$this->db->get("adm_tb")->row_array();
            return $adm;
        }

    
}