<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginADM extends CI_Controller {

	public function index(){   
                $dados['titulo'] = "login ADM - PHarmaciaP";

        
                $this->load->view('templates/header', $dados);
                $this->load->view('templates/nav-top', $dados);
                $this->load->view('pages/loginadm', $dados);
                $this->load->view('templates/footer', $dados);
                $this->load->view('templates/js', $dados);
    
        }
        //acessar a página com o cadastro criado
        
        public function logaradm(){

                //CARREGANDO MODEL

                $this->load->model("adms_model");

                //checar se informações inseridas estão no banco
                //logando pelo USARNEME
                $matricula_adm = $this->input->post("matricula_adm");
                $senha_adm = ($this->input->post("senha_adm"));
                //depois de montar matricula e senha JOGA PARA UMA VARIAVEL @USUARIO
                $adm = $this->adms_model->logarAdm($matricula_adm, $senha_adm);
                //verificando se usuario existe
                if($adm){
                        //LOGAR ***** SET_USERDATA
                        $this->session->set_userdata("admin_logado", $adm);
                        //direcionando para a página desse usuario
                        //pode usar para logar na página de admin ou usuario
                        $this->session->set_flashdata("success", " admin logado com sucesso!");
                        redirect('/');
                }else{
                        $this->session->set_flashdata("danger", "admin ou senha inválidos");
                        redirect('loginadm');
                }
        }
        //FUNÇÃO DE LOGOUT
        public function logout(){
                //DESLOGAR UNSET_USERDATA
                $this->session->unset_userdata("admin_logado");
                $this->session->set_flashdata("success", "Deslogado com sucesso");
                redirect('/');

        }
}
