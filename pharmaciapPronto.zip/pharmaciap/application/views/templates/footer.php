<?php

?>
<footer>
    <div class="container-fluid">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <div class="col-1 pt-0">
            </div>
            <div class="col-1 pt-0">    
        </div> 
        </div></br></br></br>

        <div id="rodape">
            <center>
                JoTy Desenvolvimento - CNPJ: 15.512.147/0041-90 © Todos os direitos reservados. 2019</br>
                <img src="https://cdn.worldvectorlogo.com/logos/tinder-icon.svg" width="20px"> </n>JoTy interprise
            </center></br>
        </div>
    </div>
</footer>
