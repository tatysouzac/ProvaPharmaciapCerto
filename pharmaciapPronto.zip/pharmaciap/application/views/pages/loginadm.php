
<?php

?>
<section class="page-content">
    <div class="container">

        <?php if($this->session->flashdata("success")) : ?>
                    <p class="alert alert-success"><?= $this->session->flashdata("success") ?></p>
        <?php endif ?>

        <?php if($this->session->flashdata("danger")) : ?>
                    <p class="alert alert-danger"><?= $this->session->flashdata("danger") ?></p>
        <?php endif ?>
        <div class="row"><hr>
            <div class="col-md-12" style="margin-top: 35px; color: #2f2f2f">
                <div class="jumbotron" style="background-color: #f0f0f0;">
                    <h2>Entrar</h2>
                    <form action="loginadm/logaradm" method="post">

                        <div class="form-group">
                            <label for="matricula_adm">Matricula do ADM</label>
                            <!-- required = campo nunca poderá ser vazio -->
                            <input required type="text" name="matricula_adm" id="matricula_adm" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="senha_adm">Senha</label>
                            <!-- required = campo nunca poderá ser vazio -->
                            <input required type="password" name="senha_adm" id="senha_adm" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>