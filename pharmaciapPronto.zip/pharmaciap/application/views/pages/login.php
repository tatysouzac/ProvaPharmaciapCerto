<?php

?>
<section class="page-content">
    <div class="container">

    <?php if($this->session->flashdata("success")) : ?>
                    <p class="alert alert-success"><?= $this->session->flashdata("success") ?></p>
        <?php endif ?>

        <?php if($this->session->flashdata("danger")) : ?>
                    <p class="alert alert-danger"><?= $this->session->flashdata("danger") ?></p>
        <?php endif ?>
        
        <div class="row"><hr>
            <div class="col-md-12" style="margin-top: 35px; color: #86817D">
                <div class="jumbotron" style="background-color: #1111;">
                    <h2>Entrar</h2>
                    <form action="login/logar" method="post">

                        <div class="form-group">
                            <label for="matricula">Matricula do Usuário</label>
                            <!-- required = campo nunca poderá ser vazio -->
                            <input required type="text" name="matricula" id="matricula" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="senha">Senha</label>
                            <!-- required = campo nunca poderá ser vazio -->
                            <input required type="password" name="senha" id="senha" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>