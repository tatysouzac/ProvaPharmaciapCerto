<?php

?>

<section class="contato">
    <div class="container">

        <div class="contato-titulo">
            <h1>Fale Conosco</h1>
            <hr class="contato-hr">
            <p class="descricao-contato">Para entrar em contato, utilize o formulário abaixo:</p>
        </div>

        <div class="contato-form">
            <div class="row clearfix">
                <div class="col-md-7">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="nome" class="descricao-contato">Nome</label>
                            <input required type="text" class="form-control" id="nome" name="nome">
                        </div>

                        <div class="form-group">
                            <label for="email" class="descricao-contato">Email</label>
                            <input required type="text" class="form-control" id="email" name="email">
                        </div>

                        <div class="form-group">
                            <label for="mensagem" class="descricao-contato">Mensagem</label>
                            <textarea required name="mensagem" id="mensagem" cols="20" rows="7" class="form-control"></textarea>
                        </div>

                        <button required type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                            Enviar
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                            Mensagem enviada com sucesso.
                            </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>