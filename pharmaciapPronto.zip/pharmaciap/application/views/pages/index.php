<section class="page-content">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <img src="https://www.dierbergs.com/-/media/Corporate/Pharmacy/Categories/548x312-Pharmacy-Preferred-Plans.ashx" style="width: 100%;" heigth="80%">
            </div>
            <hr>
            <div class="col-md-12" style="margin-top: 35px; color: #86817D">

                <?php if($this->session->flashdata("success")) : ?>
                    <p class="alert alert-success"><?= $this->session->flashdata("success") ?></p>
                <?php endif ?>

                <?php if($this->session->flashdata("danger")) : ?>
                    <p class="alert alert-danger"><?= $this->session->flashdata("danger") ?></p>
                <?php endif ?>

            </div>

            <hr>

            <div class="col-md-12">
                <h1 style="text-align: center; margin-bottom: 30px; color: #86817D">Últimos Produtos</h1>
                <div class="row clearfix" style="text-align: justify">
                <?php foreach ($produtos as $produto) : ?>
                    <div class="col-md-3" Style="...">
                        <div class="card personagem" style="...">
<!--------------------------------------------------------------- Foto ------------------------------------------------------->
                            <img class="card-img-top" src="assets/images/produtos/<?= $produto['nome_imagem'] ?>" alt="Card">
                            <div class="card-body">

<!--------------------------------------------------------------- Nome ------------------------------------------------------->
                                <h5 class="card-title"><?= $produto['nome'] ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>